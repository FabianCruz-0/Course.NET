using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
class MainClass {
  public static void Main (string[] args) {
     //Declarar un arreglo de numeros e imprimir el más grande.
            int[] valores2 = new int[7] {1234,2314,234,345,6,3423,123};
            int i;
            int max = valores2[0];
            for(i=0;i<7;i++)
            {
              if(max<valores2[i])
              {
                max=valores2[i];
              }
            }
            System.Console.WriteLine("\n\n Primer problema:");
            System.Console.WriteLine(max);
System.Console.WriteLine("\n\n Segundo problema:");
      //Declarar una lista vacía y agregar 10 datos en ella.
          List<int> milista1 = new List<int>();
          int j;
          for(j=0;j<10;j++)
          {
            milista1.Add(j);
            System.Console.WriteLine(milista1[j]);
          }


      //Declarar una lista llamada materia y otra calificación.
      //La de calificacion numero aleatorio de 0 a 100.
      System.Console.WriteLine("\n\n Tercer problema: \n");

      List<string> materia = new List<string>() {"Español","Mate","Historia","Prog","Psicologia","base de datos","algoritmos","sasdf","sddv","qsda"};
      
      List<float> calificacion = new List<float>();
      int k;
      
      for(k=0;k<10;k++)
          {
            var guid = Guid.NewGuid();
        var justNumbers = new String(guid.ToString().Where(Char.IsDigit).ToArray());
        var seed = int.Parse(justNumbers.Substring(0, 4));

        var random = new Random(seed);
        var value = random.Next(0, 100);
            calificacion.Add(value);
            System.Console.WriteLine(materia[k] + " : "+ calificacion[k]);
          }

  }
}